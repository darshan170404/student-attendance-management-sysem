<?php
session_start();
require_once "config.php";
if (!isset($_SESSION['teacher'])) {
    header("Location: index.php");
    exit;
}

$info = $error = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id = (int)($_POST['id'] ?? 0);
    if ($id <= 0) {
        $error = "Please enter a valid Student ID.";
    } else {
        $stmt = $conn->prepare("DELETE FROM students WHERE id=?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            if ($stmt->affected_rows > 0) {
                $info = "Student removed. <a href='dashboard.php'>Go back</a>";
            } else {
                $error = "No student found with that ID.";
            }
        } else {
            $error = "Error: " . $stmt->error;
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Remove Student</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
</head>
<body>
<div class="form-container wide-container" style="width: 95% !important; max-width: none !important;">
    <h2>Remove Student</h2>
    <?php if ($info): ?><div class="info"><?php echo $info; ?></div><?php endif; ?>
    <?php if ($error): ?><div class="error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    <form method="POST" autocomplete="off">
        <input type="number" name="id" placeholder="Student ID" required><br>
        <button type="submit">Remove</button>
    </form>
    <p><a href="dashboard.php">Back to Dashboard</a></p>
</div>
</body>
</html>
