<?php
session_start();
require_once "config.php";
if (!isset($_SESSION['teacher'])) {
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Teacher Dashboard</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
</head>
<body>
<div class="dashboard wide-container" style="width: 95% !important; max-width: none !important;">
    <h2>Welcome, <?php echo htmlspecialchars($_SESSION['teacher']); ?>!</h2>
    <div class="actions">
        <a href="add_student.php"><button>Add Student</button></a>
        <a href="remove_student.php"><button>Remove Student</button></a>
        <a href="mark_attendance.php"><button>Mark Attendance</button></a>
        <a href="attendance_report.php"><button>Attendance Report</button></a>
        <a href="logout.php"><button>Logout</button></a>
    </div>
</div>

<h3>Student List</h3>
<table>
    <tr>
        <th>ID</th>
        <th>Roll No</th>
        <th>Name</th>
        <th>Class</th>
        <th>City</th>
    </tr>
    <?php
    $res = $conn->query("SELECT id, roll_no, name, class, city FROM students ORDER BY id DESC");
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            echo "<tr>
                    <td>".(int)$row['id']."</td>
                    <td>".htmlspecialchars($row['roll_no'])."</td>
                    <td>".htmlspecialchars($row['name'])."</td>
                    <td>".htmlspecialchars($row['class'])."</td>
                    <td>".htmlspecialchars($row['city'])."</td>
                  </tr>";
        }
    }
    ?>
</table>
</body>
</html>
