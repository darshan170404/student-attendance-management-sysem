<?php
// config.php

$host = "localhost";
$user = "root";
$pass = "";
$db   = "attendance_system1";

// 1. Try connecting to the specific database
$conn = @new mysqli($host, $user, $pass, $db);

// 2. If connection failed (likely because DB doesn't exist), try connecting to server only
if ($conn->connect_error) {
    $conn = new mysqli($host, $user, $pass);
    if ($conn->connect_error) {
        die("<b>Fatal Error:</b> Could not connect to MySQL Server. Please ensure XAMPP MySQL is running.<br>" . $conn->connect_error);
    }

    // Create Database
    $conn->query("CREATE DATABASE IF NOT EXISTS `$db`");
    $conn->select_db($db);
}

// 3. Ensure tables exist
// We check for one main table 'teachers'. If missing, we create all tables.
$tableCheck = $conn->query("SHOW TABLES LIKE 'teachers'");
if ($tableCheck->num_rows == 0) {
    // Structure from install.sql
    $sql_commands = [
        "CREATE TABLE IF NOT EXISTS teachers (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(100) NOT NULL UNIQUE,
            email VARCHAR(100) NOT NULL,
            password VARCHAR(255) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )",
        "CREATE TABLE IF NOT EXISTS students (
            id INT AUTO_INCREMENT PRIMARY KEY,
            roll_no VARCHAR(20) NOT NULL UNIQUE,
            name VARCHAR(100) NOT NULL,
            age INT,
            class VARCHAR(50),
            city VARCHAR(100),
            state VARCHAR(100),
            country VARCHAR(100),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )",
        "CREATE TABLE IF NOT EXISTS attendance (
            id INT AUTO_INCREMENT PRIMARY KEY,
            student_id INT NOT NULL,
            date DATE NOT NULL,
            status ENUM('Present','Absent') NOT NULL DEFAULT 'Present',
            CONSTRAINT fk_att_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
            UNIQUE KEY uniq_student_date (student_id, date)
        )"
    ];

    foreach ($sql_commands as $sql) {
        if (!$conn->query($sql)) {
            die("<b>Setup Error:</b> Failed to create tables automatically. " . $conn->error);
        }
    }
}

$conn->set_charset("utf8mb4");
?>
