# How to Run the Attendance System

Since you are using XAMPP, follow these steps to run your project:

## 1. Start XAMPP
- Open the **XAMPP Control Panel**.
- Click **Start** for **Apache** and **MySQL**.
- Ensure they are running (green background).

## 2. Setup the Database
This project requires a MySQL database. You have two options:

### Option A: Automatic Setup (Recommended)
1. Open your web browser.
2. Go to: [http://localhost/attandance/setup_wizard.php](http://localhost/attandance/setup_wizard.php)
3. Follow the on-screen instructions to create the database and tables.

### Option B: Manual Setup
1. Open your web browser and go to `http://localhost/phpmyadmin`.
2. Click **New** in the sidebar.
3. Create a database named `attendance_system1`.
4. Click on the `attendance_system1` database.
5. Click **Import** in the top menu.
6. Choose the file `install.sql` from your project folder (`c:\xampp\htdocs\attandance\install.sql`) and click **Go**.

## 3. Run the Application
- Open your browser and visit: [http://localhost/attandance/index.php](http://localhost/attandance/index.php)
- You should see the login page.

## Troubleshooting
- **Database Error?** Check `config.php` and make sure the username/password matches your XAMPP settings (default is usually user: `root`, password: empty).
- **404 Not Found?** Ensure the folder name in `htdocs` matches `attandance` exactly.
