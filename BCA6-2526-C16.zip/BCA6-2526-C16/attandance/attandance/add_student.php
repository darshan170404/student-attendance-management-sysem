<?php
session_start();
require_once "config.php";
if (!isset($_SESSION['teacher'])) {
    header("Location: index.php");
    exit;
}

$info = $error = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $roll_no = trim($_POST['roll_no'] ?? "");
    $name    = trim($_POST['name'] ?? "");
    $age     = $_POST['age'] !== "" ? (int)$_POST['age'] : null;
    $class   = trim($_POST['class'] ?? "");
    $city    = trim($_POST['city'] ?? "");
    $state   = trim($_POST['state'] ?? "");
    $country = trim($_POST['country'] ?? "");

    if ($roll_no === "" || $name === "") {
        $error = "Roll No and Name are required.";
    } else {
        $stmt = $conn->prepare("INSERT INTO students (roll_no, name, age, class, city, state, country) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssissss", $roll_no, $name, $age, $class, $city, $state, $country);
        if ($stmt->execute()) {
            $info = "Student added successfully. <a href='dashboard.php'>Go back</a>";
        } else {
            $error = "Error: " . $stmt->error;
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Student</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
</head>
<body>
<div class="form-container wide-container" style="width: 95% !important; max-width: none !important;">
    <h2>Add Student</h2>
    <?php if ($info): ?><div class="info"><?php echo $info; ?></div><?php endif; ?>
    <?php if ($error): ?><div class="error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    <form method="POST" autocomplete="off">
        <input type="text" name="roll_no" placeholder="Roll No" required><br>
        <input type="text" name="name" placeholder="Full Name" required><br>
        <input type="number" name="age" placeholder="Age" min="1"><br>
        <input type="text" name="class" placeholder="Class"><br>
        <input type="text" name="city" placeholder="City"><br>
        <input type="text" name="state" placeholder="State"><br>
        <input type="text" name="country" placeholder="Country"><br>
        <button type="submit">Add Student</button>
    </form>
    <p><a href="dashboard.php">Back to Dashboard</a></p>
</div>
</body>
</html>
