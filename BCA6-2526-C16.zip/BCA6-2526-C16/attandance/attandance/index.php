<?php
session_start();
require_once "config.php";

if (isset($_SESSION['teacher'])) {
    header("Location: dashboard.php");
    exit;
}

$error = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST['username'] ?? "");
    $password = trim($_POST['password'] ?? "");

    if ($stmt = $conn->prepare("SELECT id, username, password FROM teachers WHERE username=? LIMIT 1")) {
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
    } else {
        $error = "Database Error: " . $conn->error;
        $row = null;
    }

    if ($row && password_verify($password, $row['password'])) {
        $_SESSION['teacher_id'] = $row['id'];
        $_SESSION['teacher'] = $row['username'];
        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Invalid username or password.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Teacher Login</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
</head>
<body>
<div class="form-container wide-container" style="width: 95% !important; max-width: none !important;">
    <h2>Login</h2>
    <?php if ($error): ?><div class="error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    <form method="POST" autocomplete="off">
        <input type="text" name="username" placeholder="Username" required><br>
        <input type="password" name="password" placeholder="Password" required><br>
        <button type="submit">Login</button>
    </form>
    <p>New teacher? <a href="register.php">Register here</a></p>
</div>
</body>
</html>
