<?php
// setup_wizard.php
// A simple script to help set up the database for the user

$host = 'localhost';
$user = 'root';
$pass = '';

$message = "";
$status = "";

// 1. Check Connection to MySQL
$conn = new mysqli($host, $user, $pass);
if ($conn->connect_error) {
    $status = "error";
    $message = "Could not connect to MySQL. Please check XAMPP Control Panel and ensure MySQL is running.<br>Error: " . $conn->connect_error;
} else {
    // 2. Check Database
    $db_name = 'attendance_system1';
    $db_selected = $conn->select_db($db_name);

    if (isset($_POST['setup'])) {
        // Run Setup
        $sqlList = file_get_contents('install.sql');
        
        // Multi-query execution
        if ($conn->multi_query($sqlList)) {
            do {
                // Consume results to clear the buffer
                if ($result = $conn->store_result()) {
                    $result->free();
                }
            } while ($conn->more_results() && $conn->next_result());
            
            $status = "success";
            $message = "Database and tables created successfully! <a href='index.php'>Go to Login</a>";
        } else {
            $status = "error";
            $message = "Error executing install.sql: " . $conn->error;
        }
    } elseif (!$db_selected) {
        $status = "warning";
        $message = "Database '$db_name' does not exist yet.";
    } else {
        // Database exists, check tables
        $result = $conn->query("SHOW TABLES LIKE 'students'");
        if ($result && $result->num_rows > 0) {
            $status = "success";
            $message = "Database setup looks correct! You can likely <a href='index.php'>Run the App</a>.";
        } else {
            $status = "warning";
            $message = "Database exists but tables might be missing.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Setup Wizard</title>
    <style>
        body { font-family: sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; background: #f0f2f5; }
        .card { background: white; padding: 2rem; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); max-width: 500px; width: 100%; text-align: center; }
        .error { color: #d32f2f; background: #ffebee; padding: 10px; border-radius: 4px; margin-bottom: 1rem; }
        .success { color: #388e3c; background: #e8f5e9; padding: 10px; border-radius: 4px; margin-bottom: 1rem; }
        .warning { color: #f57c00; background: #fff3e0; padding: 10px; border-radius: 4px; margin-bottom: 1rem; }
        button { background: #007bff; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; font-size: 16px; }
        button:hover { background: #0056b3; }
        a { color: #007bff; text-decoration: none; font-weight: bold; }
    </style>
</head>
<body>
    <div class="card">
        <h1>🛠 Implementation Setup</h1>
        
        <?php if ($status == 'error'): ?>
            <div class="error"><?php echo $message; ?></div>
        <?php elseif ($status == 'success'): ?>
            <div class="success"><?php echo $message; ?></div>
        <?php elseif ($status == 'warning'): ?>
            <div class="warning"><?php echo $message; ?></div>
            <form method="post">
                <button type="submit" name="setup">Run Automatic Setup</button>
            </form>
        <?php endif; ?>

        <?php if ($status == ''): ?>
            <p>Checking environment...</p>
        <?php endif; ?>
    </div>
</body>
</html>
