<?php
session_start();
require_once "config.php";
if (!isset($_SESSION['teacher'])) {
    header("Location: index.php");
    exit;
}

// Filters (optional)
$filter_name = trim($_GET['name'] ?? "");
$filter_date = trim($_GET['date'] ?? "");

$sql = "SELECT a.date, s.roll_no, s.name, s.class, a.status 
        FROM attendance a 
        JOIN students s ON a.student_id = s.id";
$conditions = [];
$params = [];
$types = "";

if ($filter_name !== "") {
    $conditions[] = "s.name LIKE ?";
    $params[] = "%$filter_name%";
    $types .= "s";
}
if ($filter_date !== "") {
    $conditions[] = "a.date = ?";
    $params[] = $filter_date;
    $types .= "s";
}
if ($conditions) {
    $sql .= " WHERE " . implode(" AND ", $conditions);
}
$sql .= " ORDER BY a.date DESC, s.roll_no ASC";

$stmt = $conn->prepare($sql);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Attendance Report</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style> canvas { max-height: 400px; } </style>
</head>
<body>
<div class="dashboard wide-container" style="width: 95% !important; max-width: none !important;">
    <h2>Attendance Report</h2>
    <form method="GET" class="actions">
        <label>From: <input type="date" name="from" value="<?php echo $from; ?>"></label>
        <label>To: <input type="date" name="to" value="<?php echo $to; ?>"></label>
        <button type="submit">Filter</button>
    </form>
    <div style="width:80%; margin:auto;">
        <canvas id="attChart"></canvas>
    </div>
</div>

<div class="form-container wide-container" style="width: 95% !important; max-width: none !important;">
    <h3>Filter</h3>
    <form method="GET">
        <input type="text" name="name" placeholder="Student name contains..." value="<?php echo htmlspecialchars($filter_name); ?>">
        <input type="date" name="date" value="<?php echo htmlspecialchars($filter_date); ?>">
        <button type="submit">Apply</button>
        <a href="attendance_report.php"><button type="button">Clear</button></a>
    </form>
</div>

<table>
    <tr>
        <th>Date</th>
        <th>Roll No</th>
        <th>Name</th>
        <th>Class</th>
        <th>Status</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo htmlspecialchars($row['date']); ?></td>
            <td><?php echo htmlspecialchars($row['roll_no']); ?></td>
            <td><?php echo htmlspecialchars($row['name']); ?></td>
            <td><?php echo htmlspecialchars($row['class']); ?></td>
            <td><?php echo htmlspecialchars($row['status']); ?></td>
        </tr>
    <?php endwhile; $stmt->close(); ?>
</table>
</body>
</html>
