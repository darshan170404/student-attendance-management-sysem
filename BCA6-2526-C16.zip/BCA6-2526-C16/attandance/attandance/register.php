<?php
session_start();
require_once "config.php";

$info = $error = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST['username'] ?? "");
    $email    = trim($_POST['email'] ?? "");
    $password = trim($_POST['password'] ?? "");

    if ($username === "" || $email === "" || $password === "") {
        $error = "All fields are required.";
    } else {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        if ($stmt = $conn->prepare("INSERT INTO teachers (username, email, password) VALUES (?, ?, ?)")) {
            $stmt->bind_param("sss", $username, $email, $hash);
            try {
                if ($stmt->execute()) {
                    $info = "Registration successful. <a href='index.php'>Login here</a>";
                } else {
                     // This block might not be reached if exceptions are thrown, but kept for fallback
                    $error = "Error executing query: " . $stmt->error;
                }
            } catch (mysqli_sql_exception $e) {
                if ($e->getCode() == 1062) { // 1062 is Duplicate Entry
                    $error = "Username '<b>" . htmlspecialchars($username) . "</b>' already exists. Please choose another.";
                } else {
                    $error = "Database Error: " . $e->getMessage();
                }
            }
            $stmt->close();
        } else {
            $error = "Database Error: Unable to prepare query. " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Register Teacher</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
</head>
<body>
<div class="form-container wide-container" style="width: 95% !important; max-width: none !important;">
    <h2>Register Teacher</h2>
    <?php if ($info): ?><div class="info"><?php echo $info; ?></div><?php endif; ?>
    <?php if ($error): ?><div class="error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    <form method="POST" autocomplete="off">
        <input type="text" name="username" placeholder="Username" required><br>
        <input type="email" name="email" placeholder="Email" required><br>
        <input type="password" name="password" placeholder="Password" required><br>
        <button type="submit">Register</button>
    </form>
    <p>Already registered? <a href="index.php">Login</a></p>
</div>
</body>
</html>
