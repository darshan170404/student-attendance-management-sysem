<?php
session_start();
require_once "config.php";
if (!isset($_SESSION['teacher'])) {
    header("Location: index.php");
    exit;
}

$info = $error = "";
$today = date("Y-m-d");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $statuses = $_POST['status'] ?? [];

    // transactional safety (optional)
    $conn->begin_transaction();
    try {
        foreach ($statuses as $student_id => $status) {
            $student_id = (int)$student_id;
            $status = ($status === 'Absent') ? 'Absent' : 'Present';

            // Try insert; if duplicate, update
            $stmt = $conn->prepare("INSERT INTO attendance (student_id, date, status) VALUES (?, ?, ?)
                                    ON DUPLICATE KEY UPDATE status=VALUES(status)");
            $stmt->bind_param("iss", $student_id, $today, $status);
            $stmt->execute();
            $stmt->close();
        }
        $conn->commit();
        $info = "Attendance saved for " . date("d-m-Y", strtotime($today)) . ". <a href='dashboard.php'>Go back</a>";
    } catch (Throwable $e) {
        $conn->rollback();
        $error = "Error saving attendance: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Mark Attendance</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
</head>
<body>
<div class="form-container wide-container" style="width: 95% !important; max-width: none !important;">
    <h2>Mark Attendance (<?php echo date("d-m-Y", strtotime($today)); ?>)</h2>
    <?php if ($info): ?><div class="info"><?php echo $info; ?></div><?php endif; ?>
    <?php if ($error): ?><div class="error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <form method="POST">
        <table>
            <tr>
                <th>Roll No</th>
                <th>Name</th>
                <th>Class</th>
                <th>Status</th>
            </tr>
            <?php
            $res = $conn->query("SELECT id, roll_no, name, class FROM students ORDER BY roll_no+0, roll_no");
            while ($row = $res->fetch_assoc()) {
                $sid = (int)$row['id'];

                // Pre-select previously saved status (if any)
                $pre = $conn->prepare("SELECT status FROM attendance WHERE student_id=? AND date=?");
                $pre->bind_param("is", $sid, $today);
                $pre->execute();
                $prev = $pre->get_result()->fetch_assoc();
                $pre->close();

                $isPresent = !$prev || $prev['status'] === 'Present';
                echo "<tr>
                        <td>".htmlspecialchars($row['roll_no'])."</td>
                        <td>".htmlspecialchars($row['name'])."</td>
                        <td>".htmlspecialchars($row['class'])."</td>
                        <td>
                            <label><input type='radio' name='status[$sid]' value='Present' ".($isPresent ? "checked" : "")."> Present</label>
                            <label><input type='radio' name='status[$sid]' value='Absent' ".(!$isPresent ? "checked" : "")."> Absent</label>
                        </td>
                      </tr>";
            }
            ?>
        </table>
        <button type="submit">Save Attendance</button>
    </form>
    <p><a href="dashboard.php">Back to Dashboard</a></p>
</div>
</body>
</html>
